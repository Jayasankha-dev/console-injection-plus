chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['savedScripts', 'globalBlocked', 'forceCloseEnabled'], (res) => {
        if (!res.savedScripts) chrome.storage.local.set({ savedScripts: [] });
        if (!res.globalBlocked) chrome.storage.local.set({ globalBlocked: [] });
        if (res.forceCloseEnabled === undefined) chrome.storage.local.set({ forceCloseEnabled: false });
    });
});

// JSON Rules (DeclarativeNetRequest) Update Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updateNetRules") {
        const rules = request.rules;
        chrome.declarativeNetRequest.getDynamicRules((oldRules) => {
            const oldRuleIds = oldRules.map(r => r.id);
            chrome.declarativeNetRequest.updateDynamicRules({
                removeRuleIds: oldRuleIds,
                addRules: rules
            }).then(() => {
                sendResponse({ success: true });
            }).catch((err) => {
                sendResponse({ success: false, error: err.message });
            });
        });
        return true; 
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) return;

    if (changeInfo.status === 'loading') {
        chrome.storage.local.get(['globalBlocked', 'forceCloseEnabled'], (res) => {
            if (res.forceCloseEnabled && res.globalBlocked && res.globalBlocked.length > 0) {
                const isBlocked = res.globalBlocked.some(domain => tab.url.includes(domain));
                if (isBlocked) {
                    chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        func: () => { window.onbeforeunload = null; }
                    }).then(() => {
                        chrome.tabs.remove(tabId).catch(() => {});
                    }).catch(() => {
                        chrome.tabs.remove(tabId).catch(() => {});
                    });
                    return;
                }
            }
        });
    }

    if (changeInfo.status === 'loading' && tab.url) {
        chrome.storage.local.get(['savedScripts'], (res) => {
            const scripts = res.savedScripts || [];
            scripts.forEach(script => {
                if (!script.enabled) return;
                let isMatch = false;
                try {
                    if (script.pattern.startsWith('/') && script.pattern.endsWith('/')) {
                         const regex = new RegExp(script.pattern.slice(1, -1));
                         isMatch = regex.test(tab.url);
                    } else {
                         const regex = new RegExp(script.pattern);
                         isMatch = regex.test(tab.url) || tab.url.includes(script.pattern);
                    }
                } catch(e) {
                    isMatch = tab.url.includes(script.pattern);
                }
                if (isMatch) injectScript(tabId, script);
            });
        });

        chrome.storage.local.get(['domainFilters'], (res) => {
            try {
                const host = new URL(tab.url).hostname;
                const filters = res.domainFilters || {};
                if (filters[host]) {
                    chrome.scripting.insertCSS({
                        target: { tabId: tabId },
                        css: filters[host]
                    }).catch(() => {});
                }
            } catch(e) {}
        });
    }
});

function injectScript(tabId, script) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: "MAIN",
        func: (code, name) => {
            try {
                window.onbeforeunload = null;
 window.addEventListener('beforeunload', (event) => {
                    event.stopImmediatePropagation();
                }, true);

                const attrName = 'data-injected-' + name.replace(/\s/g, '');
                if(document.documentElement.hasAttribute(attrName)) return;
                const scriptEl = document.createElement('script');
                scriptEl.textContent = `(function(){ try { ${code} } catch(err) { console.error(err); } })();`;
                (document.head || document.documentElement).appendChild(scriptEl);
                scriptEl.remove();
                document.documentElement.setAttribute(attrName, 'true');
            } catch (e) { console.error(e); }
        },
        args: [script.code, script.name]
    }).then(() => {
        chrome.runtime.sendMessage({ action: "log", msg: `Executed: ${script.name}`, type: "success" }).catch(()=>{});
    }).catch(() => {});
}