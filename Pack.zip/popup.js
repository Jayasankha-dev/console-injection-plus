let currentHost = "";
let editingScriptId = null;
let allScriptsCache = []; 

document.addEventListener('DOMContentLoaded', () => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if(tabs[0] && tabs[0].url) {
            try {
                const urlObj = new URL(tabs[0].url);
                if(urlObj.protocol === 'chrome:' || urlObj.protocol === 'edge:') {
                     currentHost = "System Page";
                } else {
                     currentHost = urlObj.hostname;
                }
                document.getElementById('currentDomain').innerText = currentHost;
                loadAllData();
            } catch(e) {
                document.getElementById('currentDomain').innerText = "Local/System";
            }
        }
    });

    initializeEventListeners();
// initializeEventListeners 
document.getElementById('saveNetRules').onclick = () => {
    const jsonText = document.getElementById('netRulesJson').value;
    try {
        const rules = JSON.parse(jsonText);
        
        chrome.runtime.sendMessage({ action: "updateNetRules", rules: rules }, (response) => {
            if (response && response.success) {
                addLog("Network Rules Updated!", "success");
            } else {
                alert("Error updating rules: " + response.error);
            }
        });
        
        chrome.storage.local.set({ customNetRules: jsonText });
    } catch (e) {
        alert("Invalid JSON format!");
    }
};
document.getElementById('btnQuickAdd').onclick = () => {
    const domain = document.getElementById('quickSiteInput').value.trim();
    if (!domain) return;

    const netArea = document.getElementById('netRulesJson');
    let rules = [];

    try {
        rules = JSON.parse(netArea.value || "[]");
    } catch (e) {
        rules = [];
    }

    const newId = rules.length > 0 ? Math.max(...rules.map(r => r.id)) + 1 : 1000;

  
    const newRule = {
        "id": newId,
        "priority": 1,
        "action": { "type": "block" },
        "condition": { 
            "urlFilter": `*${domain}*`, 
            "resourceTypes": ["main_frame", "sub_frame", "script"] 
        }
    };

    rules.push(newRule);
    netArea.value = JSON.stringify(rules, null, 2);
    
    
    document.getElementById('saveNetRules').click();
    
    document.getElementById('quickSiteInput').value = "";
    
   
    alert(`✅ JSON Rule Generated: ${domain} added to Network Filters.`);
};


chrome.storage.local.get(['customNetRules'], (res) => {
    if (res.customNetRules) {
        document.getElementById('netRulesJson').value = res.customNetRules;
    }
});
    
    // Animation start 
    startCodeAnimation();

    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === "log") {
            addLog(request.msg, request.type);
        }
    });
});

function initializeEventListeners() {
    // Tab Switching
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(btn => {
        btn.onclick = () => {
            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            btn.classList.add('active');
            const targetContent = document.getElementById(btn.getAttribute('data-target'));
            if (targetContent) targetContent.classList.add('active');
        };
    });

    // Search Logic
    const searchInput = document.getElementById('scriptSearch');
    searchInput.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        const filtered = allScriptsCache.filter(s => 
            s.name.toLowerCase().includes(term) || 
            s.pattern.toLowerCase().includes(term)
        );
        renderScriptList(filtered);
    });

    // Modal & Buttons
    const modal = document.getElementById('editorModal');
    document.getElementById('addNewBtn').onclick = () => openEditor();
    document.getElementById('closeModal').onclick = () => modal.style.display = 'none';

    document.getElementById('saveModal').onclick = () => {
        const name = document.getElementById('modalScriptName').value.trim();
        const pattern = document.getElementById('modalScriptPattern').value.trim();
        const code = document.getElementById('modalScriptCode').value;

        if(!name || !code) return alert("Name and Code are required!");

        chrome.storage.local.get(['savedScripts'], (res) => {
            let scripts = res.savedScripts || [];
            if (editingScriptId) {
                scripts = scripts.map(s => s.id === editingScriptId ? { ...s, name, pattern, code } : s);
            } else {
                scripts.push({ id: Date.now(), name, pattern, code, enabled: true });
            }
            chrome.storage.local.set({ savedScripts: scripts }, () => {
                modal.style.display = 'none';
                loadAllData();
                addLog(`Script Saved: ${name}`, 'success');
            });
        });
    };

    document.getElementById('saveRules').onclick = saveCSS;
    document.getElementById('saveBlocked').onclick = saveBlocklist;
    
    // File Upload
    document.getElementById('fileUpload').onchange = (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            openEditor();
            document.getElementById('modalScriptName').value = file.name.replace('.js', '');
            document.getElementById('modalScriptCode').value = ev.target.result;
        };
        reader.readAsText(file);
    };

    // Settings
    const forceToggle = document.getElementById('forceCloseToggle');
    forceToggle.onchange = () => {
        chrome.storage.local.set({ forceCloseEnabled: forceToggle.checked });
        addLog(`Force Close: ${forceToggle.checked ? 'ON' : 'OFF'}`, forceToggle.checked ? 'success' : 'error');
    };

    // Export/Import
    document.getElementById('exportData').onclick = () => {
        chrome.storage.local.get(null, (data) => {
            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `injection_backup_${new Date().toISOString().slice(0,10)}.json`;
            a.click();
            addLog("Backup Exported", "success");
        });
    };

    const importFile = document.getElementById('importFile');
    document.getElementById('importData').onclick = () => importFile.click();
    importFile.onchange = (e) => {
        const file = e.target.files[0];
        if(!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                chrome.storage.local.set(data, () => {
                    addLog("Backup Imported! Reloading...", "success");
                    setTimeout(() => location.reload(), 1000);
                });
            } catch(err) {
                alert("Invalid JSON file");
            }
        };
        reader.readAsText(file);
    };
}

function loadAllData() {
    chrome.storage.local.get(null, (res) => {
        allScriptsCache = res.savedScripts || []; 
        renderScriptList(allScriptsCache);
        
        const forceToggle = document.getElementById('forceCloseToggle');
        if(forceToggle) forceToggle.checked = res.forceCloseEnabled || false;
        
        if (res.domainFilters && res.domainFilters[currentHost]) {
            document.getElementById('cssRules').value = res.domainFilters[currentHost];
        }
        document.getElementById('blockedDomains').value = (res.globalBlocked || []).join('\n');
    });
}

function renderScriptList(scripts) {
    const list = document.getElementById('scriptList');
    list.innerHTML = '';

    if(scripts.length === 0) {
        list.innerHTML = '<div style="text-align:center; color:#555; padding:20px;">No scripts found</div>';
        return;
    }

    scripts.forEach(s => {
        const item = document.createElement('div');
        item.className = 'script-item';
        
        const safeName = s.name.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        
        item.innerHTML = `
            <div class="script-info"><strong>${safeName}</strong></div>
            <div class="script-actions">
                <label class="switch">
                    <input type="checkbox" class="toggle-script" ${s.enabled ? 'checked' : ''}>
                    <span class="slider"></span>
                </label>
                <button class="icon-btn edit-btn">✎</button>
                <button class="icon-btn delete-btn">🗑</button>
            </div>
        `;

        const toggle = item.querySelector('.toggle-script');
        toggle.onchange = () => toggleScript(s.id, toggle.checked);

        item.querySelector('.edit-btn').onclick = () => openEditor(s.id);
        item.querySelector('.delete-btn').onclick = () => deleteScript(s.id);

        list.appendChild(item);
    });
}

function toggleScript(id, status) {
    chrome.storage.local.get(['savedScripts'], (res) => {
        const scripts = res.savedScripts.map(s => s.id === id ? { ...s, enabled: status } : s);
        chrome.storage.local.set({ savedScripts: scripts }, () => {
            allScriptsCache = scripts;
            addLog(`Script ${status ? 'Enabled' : 'Disabled'}`, status ? 'success' : 'error');
        });
    });
}

function addLog(msg, type = 'info') {
    const win = document.getElementById('logWindow');
    if(!win) return; 
    const entry = document.createElement('div');
    entry.className = `log-entry ${type} roll-in`;
    entry.innerHTML = `<span class="prompt">></span> [${new Date().toLocaleTimeString()}] ${msg}`;
    win.appendChild(entry);
    win.scrollTop = win.scrollHeight;
}

function openEditor(id = null) {
    editingScriptId = id;
    const modal = document.getElementById('editorModal');
    if (id) {
        const s = allScriptsCache.find(x => x.id === id);
        if(s) {
            document.getElementById('modalScriptName').value = s.name;
            document.getElementById('modalScriptPattern').value = s.pattern;
            document.getElementById('modalScriptCode').value = s.code;
            document.getElementById('modalTitle').innerText = "Edit Script";
        }
    } else {
        document.getElementById('modalScriptName').value = "";
        document.getElementById('modalScriptPattern').value = currentHost !== "System Page" ? currentHost : "";
        document.getElementById('modalScriptCode').value = "";
        document.getElementById('modalTitle').innerText = "New Script";
    }
    modal.style.display = 'flex';
};

function deleteScript(id) {
    if (!confirm("Delete this script?")) return;
    chrome.storage.local.get(['savedScripts'], (res) => {
        const filtered = res.savedScripts.filter(s => s.id !== id);
        chrome.storage.local.set({ savedScripts: filtered }, () => {
            loadAllData();
            addLog("Script Deleted", "error");
        });
    });
};

function saveCSS() {
    if(!currentHost || currentHost === "System Page") return alert("Cannot save CSS for this page.");
    const val = document.getElementById('cssRules').value;
    chrome.storage.local.get(['domainFilters'], (res) => {
        const filters = res.domainFilters || {};
        filters[currentHost] = val;
        chrome.storage.local.set({ domainFilters: filters }, () => addLog("CSS Filters Saved", "success"));
    });
}

function saveBlocklist() {
    const domains = document.getElementById('blockedDomains').value.split('\n').map(x=>x.trim()).filter(x => x);
    chrome.storage.local.set({ globalBlocked: domains }, () => addLog("Blocklist Updated", "success"));
}

// Animation Function
function startCodeAnimation() {
    const streamContainer = document.getElementById('executionStream');
    if (!streamContainer) return;

    chrome.storage.local.get(['savedScripts', 'domainFilters'], (res) => {
        let liveSnippets = [];

        // JS Scripts
        if (res.savedScripts && res.savedScripts.length > 0) {
            res.savedScripts.forEach(script => {
                if (currentHost.includes(script.pattern) || script.pattern === '*' || (script.pattern && currentHost.match(script.pattern))) {
                    let shortCode = script.code.length > 50 ? script.code.substring(0, 50) + "..." : script.code;
                    liveSnippets.push({ text: `[JS] ${shortCode}`, type: "js-code" });
                }
            });
        }

        // CSS Filters
        if (res.domainFilters && res.domainFilters[currentHost]) {
            const rules = res.domainFilters[currentHost].split('\n');
            rules.forEach(rule => {
                if (rule.trim().length > 0) {
                    let shortRule = rule.length > 50 ? rule.substring(0, 50) + "..." : rule;
                    liveSnippets.push({ text: `[CSS] ${shortRule}`, type: "css-rule" });
                }
            });
        }

        // Filler Messages
        const systemFillers = [
            { text: ">> System Monitoring Active...", type: "sys-msg" },
            { text: ">> Scanning DOM Nodes...", type: "sys-msg" },
            { text: ">> Background Service Running...", type: "sys-msg" },
            { text: ">> Waiting for input...", type: "sys-msg" }
        ];

        let displayQueue = [...liveSnippets, ...systemFillers];
        
        if(liveSnippets.length > 5) {
            displayQueue = [...liveSnippets, ...systemFillers.slice(0, 2)];
        }

        setInterval(() => {
            const randomItem = displayQueue[Math.floor(Math.random() * displayQueue.length)];
            const line = document.createElement('div');
            line.className = `stream-line ${randomItem.type}`;
            const time = new Date().toISOString().split('T')[1].slice(0,8);
            line.innerText = `[${time}] ${randomItem.text}`;

            streamContainer.appendChild(line);

            if (streamContainer.childElementCount > 20) {
                streamContainer.removeChild(streamContainer.firstChild);
            }
            streamContainer.scrollTop = streamContainer.scrollHeight;

        }, 200);
    });
}